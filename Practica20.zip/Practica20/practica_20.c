#include <stdio.h>
#include <stdlib.h>

int main(void) {

  FILE *f;
  f=fopen("practica20.txt","r");
  int suma=0;
  int numero;
  while(feof(f) == 0){
    fscanf(f,"%d",&numero);
    suma=suma+numero;
  }
  printf("La suma de todos los numeros del fichero es: %d\n",suma);
  fclose(f);
  return 0;
}