#include <stdio.h>
#include <stdlib.h>

int main(void) {
  int numero;
  printf("Introduce un numero: ");
  scanf("%d",&numero);

  FILE *f;
  f=fopen("tabla.txt", "w");
  for (int i=0; i<=12;i++ ){
    fprintf(f, "%d\n",i*numero);
  }
  fclose(f);
  return 0;
}